package com.withJo.course.domain;

public class CourseVo {

}
