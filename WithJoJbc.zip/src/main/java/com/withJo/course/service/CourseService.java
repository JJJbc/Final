package com.withJo.course.service;

public interface CourseService {

}
