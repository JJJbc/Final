package com.withJo.course.service;

import org.springframework.stereotype.Service;

@Service
public class CourseServiceImpl implements CourseService{

}
