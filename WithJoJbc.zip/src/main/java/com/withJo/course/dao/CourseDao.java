package com.withJo.course.dao;

public interface CourseDao {

}
