package com.withJo.course.dao;

import org.springframework.stereotype.Repository;

@Repository
public class CourseDaoImpl implements CourseDao{

}
