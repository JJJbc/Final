package com.withJo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WithJoApplication {

	public static void main(String[] args) {
		System.out.println("스프링 실");
		SpringApplication.run(WithJoApplication.class, args);
	}

}
