package com.withJo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WithJoApplicationTests {

	@Test
	void contextLoads() {
	}

}
